from __future__ import annotations

import argparse
from pathlib import Path
import sys

from isaacsim import SimulationApp

# Add project root (…/South_Pole_DEMs/scripts) to import path
_THIS = Path(__file__).resolve()
_SCRIPT_DIR = _THIS.parent.parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

ap = argparse.ArgumentParser("Open USD terrain in Isaac Sim, optionally bind regolith, set lunar lighting.")
ap.add_argument("--usd", required=True, help="Path to a USD/USDA stage to open")
ap.add_argument("--renderer", default="RayTracedLighting", help="E.g. 'RayTracedLighting', 'PathTracing'")
ap.add_argument("--headless", action="store_true")
ap.add_argument("--viewport", choices=["default", "stage"], default="stage",
                help="default = Omniverse default viewport lights on; stage = only lights authored on the stage")
ap.add_argument("--black-sky", action="store_true", help="Disable any Dome/Sky lights for a moon-like sky")

# Sun parameters
ap.add_argument("--sun-az", type=float, default=120.0, help="Azimuth in degrees")
ap.add_argument("--sun-el", type=float, default=8.0, help="Elevation in degrees above horizon")
ap.add_argument("--sun-intensity", type=float, default=3000.0, help="UsdLux intensity (unitless multiplier)")
ap.add_argument("--sun-exposure", type=float, default=0.01, help="UsdLux exposure (EV offset)")

ap.add_argument("--fill-ratio", type=float, default=0.0,
                help="0..1 fraction of sun intensity used for a dim ambient fill (0 = off)")

# Material knobs (applied to /World/Terrain if not skipped)
ap.add_argument("--skip-material", action="store_true",
                help="Do NOT rebind material on /World/Terrain (preserve the USD's original material).")

# Path Tracing quality helpers (safe defaults; ignored on RTL)
ap.add_argument("--pt-spp", type=int, default=128, help="Path Tracing samples per pixel")
ap.add_argument("--pt-max-bounces", type=int, default=6, help="Path Tracing max bounces")

# Spawn assets
ap.add_argument("--asset-usd", default="", help="Path to any robot/asset USD to spawn")
ap.add_argument("--asset-name", default="asset", help="Name under /World")
ap.add_argument("--asset-x", type=float, default=0.0)
ap.add_argument("--asset-y", type=float, default=0.0)
ap.add_argument("--asset-yaw", type=float, default=0.0)
ap.add_argument("--drop-margin", type=float, default=0.00, help="Meters to drop above terrain")
ap.add_argument("--moon", action="store_true", help="Use 1.62 m/s^2 gravity (lunar)")
ap.add_argument("--asset-center", action="store_true",
                help="Place asset at the center of /World/Terrain")

# Straight-line locomotion knobs
ap.add_argument("--vx", type=float, default=0.5, help="Forward speed (m/s)")
ap.add_argument("--yaw-rate", type=float, default=0.0, help="Yaw rate (rad/s); 0 = straight line")
ap.add_argument("--duration", type=float, default=20.0, help="How long to drive (s)")
ap.add_argument("--hz", type=float, default=60.0, help="Control/physics rate (Hz)")
ap.add_argument("--wheel-radius", type=float, default=0.098, help="Wheel radius (m)")
ap.add_argument("--wheel-base", type=float, default=0.375, help="Wheel base (m)")

args = ap.parse_args()
print(f"[launch_isaac] Args: {args}")

simulation_app = SimulationApp({"renderer": args.renderer, "headless": args.headless})

import omni.usd
from pxr import Usd, UsdPhysics

from set_lighting import setup_daylight, configure_renderer_settings
from helper.terrain_debug import print_terrain_elevation
from set_regolith import make_and_bind_regolith  # only used if not --skip-material
from spawn_rover import (
    ensure_physics_scene,
    apply_terrain_physics,
    spawn_asset,
    world_range_for_path,
)

from isaacsim.core.api import SimulationContext
from locomotion import straight_line as SL
from omni.kit.viewport.utility import get_active_viewport_window
import omni.kit.commands

# -------------------------------
# Helpers
# -------------------------------

def get_stage() -> Usd.Stage:
    return omni.usd.get_context().get_stage()

def open_stage(path: str):
    ctx = omni.usd.get_context()
    ctx.open_stage(path)
    st = ctx.get_stage()
    st.SetTimeCodesPerSecond(60)
    print(f"[launch_isaac] Opened stage: {path}")

# -------------------------------
# Frame camera on terrain (best-effort; version-safe)
# -------------------------------

def frame_view_on_prim(prim_path: str) -> bool:
    try:
        vpw = get_active_viewport_window()
        if vpw:
            omni.kit.commands.execute("SelectPrims", old_selected_paths=[], new_selected_paths=[prim_path], expand_in_stage=True)
            if hasattr(vpw, "frame_selection"):
                vpw.frame_selection()
                return True
    except Exception as e:
        print(f"[frame][WARN] {e}")
    return False

# --- Articulation root finder ---
def find_articulation_root_path(root_path: str) -> str | None:
    st = get_stage()
    root = st.GetPrimAtPath(root_path)
    if not root or not root.IsValid():
        print(f"[articulation] Prim not found: {root_path}")
        return None

    # check the prim itself
    try:
        if root.HasAPI(UsdPhysics.ArticulationRootAPI):
            return root_path
    except Exception:
        pass

    # correct traversal: iterate the subtree rooted at `root`
    for p in Usd.PrimRange(root):
        try:
            if p.HasAPI(UsdPhysics.ArticulationRootAPI):
                return p.GetPath().pathString
        except Exception:
            pass
    return None

# -------------------------------
# Open file and configure
# -------------------------------

stage_path = str(Path(args.usd).expanduser().resolve())
open_stage(stage_path)

setup_daylight(args)
configure_renderer_settings(args)
stage = get_stage()

# Material on /World/Terrain if present (unless user wants to preserve original)
if not args.skip_material:
    root = Path(__file__).parent.parent.parent  # Points to South_Pole_DEMs
    tex_dir = root / "assets" / "textures" / "regolith"
    mesh_path = "/World/Terrain"
    
    ok = make_and_bind_regolith(
        stage,
        mesh_path,
        tex_dir=str(tex_dir),
        tile_meters=2.0,
        verbose=True
    )
    print(f"[launch_isaac] make_and_bind_regolith returned: {ok}")
else:
    print("[material] --skip-material set: preserving original material on /World/Terrain")

framed = frame_view_on_prim("/World/Terrain")
print(f"[launch_isaac] View framed: {framed}")
print("[launch_isaac] Ready.")

print_terrain_elevation(stage, "/World/Terrain")

ensure_physics_scene(stage, moon=args.moon)
apply_terrain_physics(stage, "/World/Terrain")

spawn_x, spawn_y = args.asset_x, args.asset_y
if args.asset_center:
    r = world_range_for_path(stage, "/World/Terrain")
    if r:
        spawn_x = 0.5 * (float(r.GetMin()[0]) + float(r.GetMax()[0]))
        spawn_y = 0.5 * (float(r.GetMin()[1]) + float(r.GetMax()[1]))
        print(f"[spawn] --asset-center requested -> using center ({spawn_x:.3f}, {spawn_y:.3f})")

prim_path = spawn_asset(
    stage,
    usd_path=args.asset_usd,
    name=args.asset_name,
    x=spawn_x, y=spawn_y, yaw_deg=args.asset_yaw,
    drop_margin=args.drop_margin,
    terrain_path="/World/Terrain",
    orient_to_slope=True,
)

sim = SimulationContext()
sim.set_simulation_dt(1.0/args.hz)
sim.play()

# small warmup so the referenced USD is fully ready
for _ in range(30):
    sim.step(render=False)

prim_for_ctrl = find_articulation_root_path(prim_path) or prim_path
print(f"[launch_isaac] Control prim: {prim_for_ctrl}")

metrics = SL.run_diff_drive(
    prim_path=prim_for_ctrl,
    left_wheels=None,
    right_wheels=None,
    vx=args.vx,
    yaw_rate=args.yaw_rate,
    duration=args.duration,
    hz=args.hz,
    wheel_radius=args.wheel_radius,
    wheel_base=args.wheel_base,
)

print("[straight_line] metrics:", metrics)
simulation_app.close()
