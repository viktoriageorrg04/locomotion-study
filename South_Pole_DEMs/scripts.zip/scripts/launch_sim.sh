#!/usr/bin/env bash
set -euo pipefail

# Change or empty this to disable activation attempt:
AUTO_CONDA_ENV="${AUTO_CONDA_ENV:-env_isaacsim}"

_safe_activate_conda_env() {
  local env_name="$1"
  # Only try if not already in that env
  if [[ -n "$env_name" && ( -z "${CONDA_PREFIX:-}" || "${CONDA_PREFIX##*/}" != "$env_name" ) ]]; then
    # Try known roots WITHOUT calling 'conda' first (avoids broken entrypoints)
    for CBASE in "$HOME/anaconda3" "$HOME/miniconda3" "$HOME/mambaforge" "$HOME/miniforge3" "/opt/conda"; do
      if [[ -f "$CBASE/etc/profile.d/conda.sh" ]]; then
        # shellcheck disable=SC1090
        . "$CBASE/etc/profile.d/conda.sh"
        # If 'conda' is now in the shell, try to activate; ignore errors.
        command -v conda >/dev/null 2>&1 && conda activate "$env_name" 2>/dev/null || true
        break
      fi
    done
  fi
}

[[ -n "$AUTO_CONDA_ENV" ]] && _safe_activate_conda_env "$AUTO_CONDA_ENV"

# -------- Detect a Python that can import Isaac Sim (omni) --------------------
_has_omni() {
  "$1" - "$@" <<'PY' >/dev/null 2>&1
try:
    import omni, carb  # quick import check
except Exception:
    raise SystemExit(1)
PY
}

_detect_isaac_python() {
  # 0) Explicit override
  if [[ -n "${ISAAC_PYTHON:-}" && -x "${ISAAC_PYTHON}" ]] && _has_omni "${ISAAC_PYTHON}"; then
    echo "${ISAAC_PYTHON}"; return
  fi

  # 1) Current python in PATH (works for pip-installed Isaac Sim)
  if command -v python >/dev/null 2>&1 && _has_omni python; then
    echo python; return
  fi

  # 2) Direct conda env interpreter (no 'conda' command needed)
  for CBASE in "$HOME/anaconda3" "$HOME/miniconda3" "$HOME/mambaforge" "$HOME/miniforge3" "/opt/conda"; do
    if [[ -n "${AUTO_CONDA_ENV:-}" && -x "$CBASE/envs/${AUTO_CONDA_ENV}/bin/python" ]]; then
      local CPY="$CBASE/envs/${AUTO_CONDA_ENV}/bin/python"
      if _has_omni "$CPY"; then echo "$CPY"; return; fi
    fi
  done

  # 3) Omniverse pkg launcher(s) — pick the newest that actually works
  if [[ -d "$HOME/.local/share/ov/pkg" ]]; then
    # sort by version-ish (newest first) then test
    while IFS= read -r d; do
      if [[ -x "$d/python.sh" ]] && _has_omni "$d/python.sh"; then
        echo "$d/python.sh"; return
      fi
    done < <(ls -1d "$HOME/.local/share/ov/pkg"/isaac-sim-* 2>/dev/null | sort -Vr)
  fi
  if [[ -x "/opt/isaac-sim/python.sh" ]] && _has_omni "/opt/isaac-sim/python.sh"; then
    echo "/opt/isaac-sim/python.sh"; return
  fi

  # 4) Last resort — will likely fail later, but keeps script deterministic
  echo python
}

PYTHON="$(_detect_isaac_python)"
echo "[launch_sim] Using Python: $PYTHON"

# --- Paths (resolve to absolute for safety) ---
ROOT="$(pwd)"
CREATE_SCENE="$(realpath South_Pole_DEMs/scripts/isaac_scene/create_scene.py)"
LAUNCH_ISAAC="$(realpath South_Pole_DEMs/scripts/isaac_scene/launch_isaac.py)"
USD_OUT="$(realpath South_Pole_DEMs/flat_terrain.usda)"
DEM_PATCH_DIR="$(realpath South_Pole_DEMs/dem_processed/ldem_87s_5mpp/patches)"

# Rendering / viewport
RENDERER="RayTracedLighting"   # or PathTracing
VIEWPORT="stage"
BLACK_SKY=1    # set 0 to disable
HEADLESS=0     # set 1 for headless
PT_SPP=128
PT_MAX_BOUNCES=6

# Robot (allow override via env if you want)
ASSET_USD="${ASSET_USD:-omniverse://localhost/NVIDIA/Assets/Isaac/4.5/Isaac/Robots/Clearpath/Jackal/jackal.usd}"
ASSET_NAME="${ASSET_NAME:-jackal}"
ASSET_CENTER="${ASSET_CENTER:-1}"
ASSET_X="${ASSET_X:-0.0}"
ASSET_Y="${ASSET_Y:-0.0}"
ASSET_YAW="${ASSET_YAW:-0.0}"
DROP_MARGIN="${DROP_MARGIN:-0.0}"
MOON="${MOON:-0}"

# Motion (straight line)
VX="${VX:-0.5}"
YAW_RATE="${YAW_RATE:-0.0}"
DURATION="${DURATION:-20}"
HZ="${HZ:-60}"
WHEEL_RADIUS="${WHEEL_RADIUS:-0.098}"
WHEEL_BASE="${WHEEL_BASE:-0.375}"

echo "Available DEM patches:"
select TIF in "$DEM_PATCH_DIR"/*_enhanced.tif; do
  [[ -n "${TIF:-}" ]] || { echo "Invalid selection."; continue; }
  TIF="$(realpath "$TIF")"

  echo "Creating $USD_OUT from $TIF..."
  set -x
  "$PYTHON" "$CREATE_SCENE" \
    --tif "$TIF" \
    --out "$USD_OUT" \
    --z-mode relative \
    --z-exag 1.0
  set +x

  [[ -s "$USD_OUT" ]] || { echo "[ERROR] USD was not created at $USD_OUT"; exit 1; }

  echo "Launching Isaac Sim..."
  cmd=( "$PYTHON" "$LAUNCH_ISAAC"
        --usd "$USD_OUT"
        --renderer "$RENDERER"
        --viewport "$VIEWPORT"
        --pt-spp "$PT_SPP"
        --pt-max-bounces "$PT_MAX_BOUNCES"
        --asset-usd "$ASSET_USD"
        --asset-name "$ASSET_NAME"
        --asset-x "$ASSET_X" --asset-y "$ASSET_Y" --asset-yaw "$ASSET_YAW"
        --drop-margin "$DROP_MARGIN"
        --vx "$VX" --yaw-rate "$YAW_RATE" --duration "$DURATION"
        --hz "$HZ" --wheel-radius "$WHEEL_RADIUS" --wheel-base "$WHEEL_BASE"
      )
  (( BLACK_SKY ))   && cmd+=( --black-sky )
  (( HEADLESS ))    && cmd+=( --headless )
  (( ASSET_CENTER ))&& cmd+=( --asset-center )
  (( MOON ))        && cmd+=( --moon )

  # Show the exact command (you should see --usd and --asset-usd here)
  printf '[launch_cmd] '; printf '%q ' "${cmd[@]}"; echo
  "${cmd[@]}"
  break
done
