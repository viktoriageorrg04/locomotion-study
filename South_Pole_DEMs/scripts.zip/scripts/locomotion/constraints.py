# constraints.py
from dataclasses import dataclass
from typing import Optional, Dict, Any

@dataclass
class ConstraintConfig:
    dust_mu_scale: float = 1.0            # multiply terrain dynamic friction
    payload_kg: float = 0.0               # add mass to base link
    payload_offset_xyz: tuple[float,float,float] = (0.0,0.0,0.0)  # CoM shift via payload
    check_los: bool = False               # line-of-sight stub toggle
    energy_model: str = "measured"        # "measured" or "proxy"

def apply_constraints(sim, world, art, cfg: ConstraintConfig):
    # 1) Dust (friction scaling) — simple, global material tweak
    if cfg.dust_mu_scale != 1.0:
        try:
            from pxr import UsdPhysics, PhysxSchema, Usd, Sdf
            stage = sim.get_stage()
            terrain = stage.GetPrimAtPath("/World/Terrain")
            mat_api = PhysxSchema.PhysxMaterialAPI.Get(stage, terrain.GetPath())
            if not mat_api:
                mat_api = PhysxSchema.PhysxMaterialAPI.Apply(terrain)
            dyn_mu = mat_api.GetDynamicFrictionAttr().Get() or 0.6
            stat_mu = mat_api.GetStaticFrictionAttr().Get() or 0.8
            mat_api.GetDynamicFrictionAttr().Set(dyn_mu * cfg.dust_mu_scale)
            mat_api.GetStaticFrictionAttr().Set(stat_mu * cfg.dust_mu_scale)
        except Exception as e:
            print(f"[constraints] dust_mu_scale failed (non-fatal): {e}")

    # 2) Payload (mass + CoM) — attach an invisible small cube to the base
    if cfg.payload_kg > 0:
        try:
            from isaacsim.core.prims import XFormPrimView
            base_prim = art.prim_path + "/payload_dummy"
            world.scene.add(XFormPrimView(prim_paths_expr=base_prim), translation=cfg.payload_offset_xyz)
            # Make it inertial-only
            from isaacsim.core.utils.prims import set_prim_mass
            set_prim_mass(base_prim, cfg.payload_kg)
        except Exception as e:
            print(f"[constraints] payload attach failed (non-fatal): {e}")

def los_ok_stub() -> bool:
    # Wire a real raycast later. For now, always OK.
    return True

def proxy_energy_J(distance_m: float, mass_kg: float, mu: float, g: float=1.62) -> float:
    # Simple rolling/sliding loss proxy: E ≈ μ * m * g * d
    return mu * mass_kg * g * distance_m
