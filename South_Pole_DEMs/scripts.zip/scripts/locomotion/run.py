# locomotion/run.py
from typing import Dict, Any, Optional
from .constraints import cost_of_transport

def compute_postrun_metrics(
    energy_J: float, d_net_m: float, d_track_m: float,
    avg_v_mps: float, mass_kg: float, g: float,
    mu_eff: float, tilt_stats: Dict[str, Any],
    v_forward_avg_mps: float, slip_long: Optional[float], xcom: float
) -> Dict[str, Any]:
    cot = cost_of_transport(energy_J, mass_kg, g, max(d_net_m, 1e-9))
    return {
        "E_J": round(energy_J, 1),
        "d_net_m": round(d_net_m, 2),
        "d_track_m": round(d_track_m, 2),
        "avg_v_mps": round(avg_v_mps, 3),
        "v_fwd_mps": round(v_forward_avg_mps, 3),
        "mu_eff": round(mu_eff, 3),
        "CoT": None if cot is None else round(cot, 3),
        "slip_long": None if slip_long is None else round(100*slip_long, 1),
        "xCOM": round(xcom, 3),
        **tilt_stats,
    }
