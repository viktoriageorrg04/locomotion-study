# locomotion/energy.py
from dataclasses import dataclass
from typing import Protocol, Dict, Any, Optional

class EnergyModel(Protocol):
    def reset(self) -> None: ...
    def step(self, dt: float, **obs) -> float: ...
    def finalize(self) -> Dict[str, Any]: ...

@dataclass
class ProxyEnergy(EnergyModel):
    mass_kg: float
    g: float
    mu_eff: float

    E: float = 0.0
    d_track: float = 0.0

    def reset(self) -> None:
        self.E = 0.0
        self.d_track = 0.0

    def step(self, dt: float, v_forward: float = 0.0, slip_long: Optional[float] = None, **_):
        # Simple rolling + sinkage proxy; matches your current logic
        # Power ~ mg μ v  → integfrate power over dt
        p = self.mass_kg * self.g * max(self.mu_eff, 0.0) * abs(v_forward)
        self.E += p * dt
        self.d_track += abs(v_forward) * dt
        return p

    def finalize(self):
        return dict(energy_J=self.E, distance_track_m=self.d_track)

def get_energy_model(name: str, **kwargs) -> EnergyModel:
    if name == "proxy":
        return ProxyEnergy(**kwargs)
    # placeholder for a more detailed model later (e.g., motor current -> elec energy)
    # elif name == "motor":
    #     return MotorEnergy(**kwargs)
    return ProxyEnergy(**kwargs)
